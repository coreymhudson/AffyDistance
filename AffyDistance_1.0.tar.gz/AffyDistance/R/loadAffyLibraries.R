.packageName <- 'AffyDistance'

loadAffyLibraries <-
function(){
	library(limma)
	library(gcrma)
	library(MASS)
	library(gamlss)
	library(stats4)
}

